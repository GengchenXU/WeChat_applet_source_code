//通用配置信息
let GeneralConfig = {
  openOutpay: 0,//开启货到付款
  orderNotice: '',//下单通知
  postageFreeAmount: 0//免运费金额
}

export default GeneralConfig;