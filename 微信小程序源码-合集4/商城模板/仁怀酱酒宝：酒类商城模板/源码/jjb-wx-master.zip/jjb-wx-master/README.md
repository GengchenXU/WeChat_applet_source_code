# jjb-wx a wechat MINA app
一个微信小程序的前端
微信开发者工具打开
