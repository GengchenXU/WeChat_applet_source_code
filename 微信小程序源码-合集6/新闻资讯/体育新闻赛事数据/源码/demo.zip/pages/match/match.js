import api from '../../service/index.js'

Page({
  data: {
    html:''
  },
  onLoad () {
    this.init()
  },
  init(){


  },
  onPullDownRefresh () {

  },
  onReachBottom () {

  },

})
