# wxsports

仿凤凰新闻体育板块+直播吧数据板块

<p align="center">
  <img src="./assets/img/wxsports1.gif" alt="凤凰新闻体育板块" >
  <img src="./assets/img/wxsports2.gif" alt="直播吧数据板块" >
</p>

## 项目运行

```
git clone https://github.com/crli/wxsports.git

复制到项目

**需要开启开发环境不校验请求域名以及 TLS 版本**

```


## 功能
- 体育新闻
- 足球比赛数据
