# weapp-calendar
微信小程序——倒班日历
# 关于
本小程序是一个快速计算倒休情况的日历类小工具，已经上线，使用微信扫描下面二维码可以使用。如果有人愿意贡献代码，可以联系我，我会更新到线上，感谢所有给予建议的人:)
# 我的邮箱
morningf@foxmail.com

![image](https://github.com/morningf/weapp-calendar/raw/master/二维码.jpg)
