let groupData = ['自然类', '建筑类', '鬼神类', '植物类', '动物类', '身体类', '物品类', '情爱类', '生活类', '人物类'];

module.exports = groupData;