# wx-charts-demo
Demos for [wxCharts](https://github.com/xiaolin3303/wx-charts)

可直接在微信开发工具中运行，请确保使用了最新的微信开发工具
