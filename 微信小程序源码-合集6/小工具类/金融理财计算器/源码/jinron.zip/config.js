/**
 * 小程序配置文件
 */

var host = "localhost"

var config = {

    host,

};

module.exports = config