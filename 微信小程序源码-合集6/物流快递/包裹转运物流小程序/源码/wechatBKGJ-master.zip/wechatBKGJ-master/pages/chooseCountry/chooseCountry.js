// chooseCountry.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    country:[
      {"cname":"中国","ename":"CHINA"},
      {"cname":"港澳台","ename":"GUANGZHOU"},
      { "cname": "澳大利亚", "ename": "AUSTRALIA" },
      { "cname": "马来西亚", "ename": "MALAYSIA" },
      { "cname": "新加坡", "ename": "SINGAPORE" },
      { "cname": "新西兰", "ename": "NEW ZELAND" },
      { "cname": "美国", "ename": "AMERICAN" },
      { "cname": "英国", "ename": "UNITED KINGDOM" },
      { "cname": "泰国", "ename": "THAILAND" },
      { "cname": "印度尼西亚", "ename": "INDONESIA" },
      { "cname": "荷兰", "ename": "NETTHERLANDS" },
      { "cname": "尼日利亚", "ename": "NIGERIA" },
      { "cname": "挪威", "ename": "NORWAY" },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})