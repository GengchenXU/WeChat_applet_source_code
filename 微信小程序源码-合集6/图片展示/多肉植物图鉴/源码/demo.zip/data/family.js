var familys = [
  {
    familyId: "f01",
    familyName: "景天科",
    familyImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/efdNqlNeVSwwJySqpCnb67d77.yQGLHOfM*mBD.Ipwg!/r/dB4BAAAAAAAA"
  }, {
    familyId: "f02",
    familyName: "番杏科",
    familyImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/sdokDTnzAwtn9dTI65L6nb9LqpWuQGoywcqWX8.YvwU!/r/dHUAAAAAAAAA"
  }, {
    familyId: "f03",
    familyName: "百合科",
    familyImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/gEkMksVQKX224Z*EXOPvL7XHTO*Ah9T8PiP8RTjDbJ0!/r/dB8BAAAAAAAA"
  }, {
    familyId: "f04",
    familyName: "菊科",
    familyImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/pp8eYGVy4Po9zoANtNc9UL3yPn29bh7ilslO3Wm*1U0!/r/dB4BAAAAAAAA"
  }, {
    familyId: "f05",
    familyName: "马齿苋科",
    familyImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/Tl3EaUdsOIhwfL5XeUJx9fZ73GrrTXaiVAz991z1fVo!/r/dB4BAAAAAAAA"
  }, {
    familyId: "f06",
    familyName: "其他科属",
    familyImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/SkQgSEEmqm2SF46xZeJ395LOdKIdhVYlTfMJliCgvY8!/r/dB4BAAAAAAAA"
  }
]

module.exports = {
  familys
}