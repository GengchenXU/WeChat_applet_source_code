var gens_f01 = [
  {
    familyId: "f01",
    genId: "f01g01",
    genName: "石莲花属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/efdNqlNeVSwwJySqpCnb67d77.yQGLHOfM*mBD.Ipwg!/r/dB4BAAAAAAAA"
  }, {
    familyId: "f01",
    genId: "f01g02",
    genName: "莲花掌属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/AN4.9cV2u6yg1XbX6D*0lMvs5JQG0uGDXUmrYUTww0U!/r/dB4BAAAAAAAA"
  }, {
    familyId: "f01",
    genId: "f01g03",
    genName: "青锁龙属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/aUtDaDdvvVIVeVJzyoo2t*lkyTu4wVA3H.fJtACZv6U!/r/dB4BAAAAAAAA"
  }, {
    familyId: "f01",
    genId: "f01g04",
    genName: "景天属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/KDeJKgxsN0kgHHvtifgThJBWhjEhEOE1td9HLRtED9g!/r/dBkBAAAAAAAA"
  }, {
    familyId: "f01",
    genId: "f01g05",
    genName: "伽蓝菜属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/Y7W2n8ZT3e0NJ3Xt6mDr.ttCN6E7XpgCBk2uNVacHhg!/r/dPcAAAAAAAAA"
  }, {
    familyId: "f01",
    genId: "f01g06",
    genName: "长生草属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/NWbJZ8c.Y2Fu4Xq2VlNgm1.O7z5xTLanH2.J23nb*SE!/r/dHUAAAAAAAAA"
  }, {
    familyId: "f01",
    genId: "f01g07",
    genName: "银波锦属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/.qeVowJnlPXp3DJJhosyqsCapWfCmWznxiX.Ud9mzM4!/r/dPcAAAAAAAAA"
  }, {
    familyId: "f01",
    genId: "f01g08",
    genName: "厚叶草属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/GKa3mPqdyipMt7K7SfFm0HPAFB5vNECfmvQqHuP14FY!/r/dBcBAAAAAAAA"
  },
  {
    familyId: "f01",
    genId: "f01g09",
    genName: "瓦松属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/kJs6Ah4KZw0bSkCTHSi5rrojSGEF0vCoUVmClmmCNt0!/r/dBcBAAAAAAAA"
  },
  {
    familyId: "f01",
    genId: "f01g10",
    genName: "风车草属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/m8qRuwMSJeyjwhpQ8OSUf9HhgzoP8sSOQYHeSMJ7wJw!/r/dAEBAAAAAAAA"
  },
  {
    familyId: "f01",
    genId: "f01g11",
    genName: "其他属种",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/KE*eUBKPqKoJg9PJwEq2DLW9Y.xwcLXMR9*JJ7HZMo0!/r/dHUAAAAAAAAA"
  }
]

var gens_f03=[
  {
    familyId: "f03",
    genId: "f03g01",
    genName: "十二卷属",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/gEkMksVQKX224Z*EXOPvL7XHTO*Ah9T8PiP8RTjDbJ0!/r/dB8BAAAAAAAA"
  }, {
    familyId: "f03",
    genId: "f03g02",
    genName: "其他属种",
    genImg: "http://r.photo.store.qq.com/psb?/V10VqIG41I6D36/1b3fvvqbHupxVJ2EGI4wQiHKA74.zPiL7oltK6Wzyf0!/r/dB4BAAAAAAAA"
  }
]

module.exports = {
  gens_f01,gens_f03
}