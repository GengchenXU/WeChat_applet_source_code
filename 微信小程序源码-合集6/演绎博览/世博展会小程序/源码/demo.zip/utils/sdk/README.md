# Changelog

## 1.1.4

* add browser version support umd
* remove strophe from sdk because it't too big for webpack or other compiler

## todo

* version semver