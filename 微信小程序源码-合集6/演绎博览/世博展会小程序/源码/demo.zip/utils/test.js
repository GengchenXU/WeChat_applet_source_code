function readme() {
  console.log('23333')
}

module.exports = {
  readme:readme
}
