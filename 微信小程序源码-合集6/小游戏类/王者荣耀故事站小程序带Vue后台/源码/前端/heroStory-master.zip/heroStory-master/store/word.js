var data = [{
    id: 1,
    disable: false,
    text: 'https://game.gtimg.cn/images/yxzj/act/a20161209story/world-origin-p.jpg'
  },
  {
    id: 1,
    disable: true,
    text: 'https://game.gtimg.cn/images/yxzj/act/a20161209story/world-map-p.jpg'
  },
  {
    id: 1,
    disable: true,
    text: 'https://game.gtimg.cn/images/yxzj/act/a20161209story/world-technology-p.jpg'
  },
  {
    id: 1,
    disable: true,
    text: 'https://game.gtimg.cn/images/yxzj/act/a20161209story/world-power-p.jpg'
  }
]

module.exports = data
