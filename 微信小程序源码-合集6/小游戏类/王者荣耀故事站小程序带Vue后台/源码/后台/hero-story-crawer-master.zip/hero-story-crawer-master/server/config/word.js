const wordNavUrl = {
  '482175': {
    url1: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24883/24901/m15567/list_1.shtml',
    url2: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24883/24902/m15565/list_1.shtml'
  },
  '482168': {
    url1: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24882/24899/m15567/list_1.shtml',
    url2: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24882/24900/m15565/list_1.shtml'
  },
  '482154': {
    url1: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24881/24897/m15567/list_1.shtml',
    url2: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24881/24898/m15565/list_1.shtml'
  },
  '482143': {
    url1: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24880/24895/m15567/list_1.shtml',
    url2: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24880/24896/m15565/list_1.shtml'
  },
  '482129': {
    url1: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24879/24893/m15567/list_1.shtml',
    url2: 'https://pvp.qq.com//webplat/info/news_version3/15592/18024/23901/24878/24879/24894/m15565/list_1.shtml'
  }
}

export default wordNavUrl
