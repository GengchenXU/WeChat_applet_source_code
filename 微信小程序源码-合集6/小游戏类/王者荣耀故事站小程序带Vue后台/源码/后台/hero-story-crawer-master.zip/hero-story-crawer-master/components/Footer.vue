<template>
  <footer style="color: #666">
    王者荣耀故事站&nbsp;&nbsp;<a target="_blank" href="https://blog.naice.me/">by: naice</a>
  </footer>
</template>
