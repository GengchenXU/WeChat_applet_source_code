var adList = [
  {
    infotitle:'大家好，我是广告',
    title: '解忧饺子馆',
    desc: '其中一位开发者的公众号，主要谈吃',
    qrcode: '/img/qrcode_for_gh_13d49b030a5e_258.png'
  },
  {
    infotitle: '呵呵，我也是广告',
    title: '宝宝食疗锦囊',
    desc: '这是一个专业的公众号，主要谈宝宝食疗',
    qrcode: '/img/WechatIMG72.jpeg'
  }
];
module.exports = adList;