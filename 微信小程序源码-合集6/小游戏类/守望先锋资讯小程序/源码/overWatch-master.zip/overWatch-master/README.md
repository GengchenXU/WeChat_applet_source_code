# -overWatch-
自己制作的微信小程序，守望先锋资讯站点
- 离职捣鼓的小程序，我最爱的守望 = =！
- 使用腾讯的开发者程序全程编译
- 没有认证的公众号依托，没法挂到微信上，大家凑合看下截图吧。。。
<img src="http://chuantu.biz/t6/54/1505762380x610718441.jpg" alt=""/>
<img src="http://chuantu.biz/t6/54/1505762441x610718441.jpg" alt=""/>
<img src="http://chuantu.biz/t6/54/1505762459x610718441.jpg" alt=""/>
<img src="http://chuantu.biz/t6/54/1505762469x610718441.jpg" alt=""/>




