<h1 align="center">
	<img width="170" src="./images/logo2.png" />
  	<p>sudoLite</p>
	<br>
	<br>
</h1>

> sudoLite是一款轻巧、趣萌、界面精美，具备统计、排行（即将推出），开源、免费、无广告的数独小程序

<br>

## 优点

  - 以上
  
  - 统共一百多kB，有微信就可以愉快地耍，还可将成绩分享给小伙伴炫耀
  
  - 作者是个~~偶尔~~勤劳、积极进取、有奇思妙想、视产品如孩子的人，sudoLite的后大半生就放心交给我辣
  
  - 作者还是个民主的人，欢迎任何形式、内容的反馈 ~~（虽然不一定会听）~~
  
  - 总之，你会在使用过程中发现sudoLite在不断进步，且一如既往的具有以上优点 [鞠躬]
  
## 缺点

  - 性能较差，部分安卓机会卡
  
  - 未知bug
	
	

## 截图

### 主页
<img width="270" src="https://lite.fun/images/index.jpg" />

### 统计
<img width="270" src="https://lite.fun/images/record.jpg" />

### 排行
<img width="270" src="https://lite.fun/images/rank.jpg" />

## ENJOY
<img width="270" src="https://lite.fun/images/qrcode.jpg" />
