// pages/B-follow/B-myInvite/B-myInvite.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    serviceList: [
      {
        time: '2016.06',
        img: '../../images/read100.png',
        name: '小红书',
        cont: '海外购物分享社区电商',
        st: '未披露'
      },
      {
        time: '2016.06',
        img: '../../images/read100.png',
        name: '小红书',
        cont: '海外购物分享社区电商',
        st: '未披露'
      }
    ],
    yueCha: [
      {
        time: '2017-11-27 11:00:00',
        faqi: '发起约茶',
        gong: '超期未回应',
      },
      {
        time: '2017-11-27 11:00:00',
        faqi: '发起约茶',
        gong: '超期未回应',
      }
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  //去评价
  toEvaluate: function () {
    let that = this;
    wx.navigateTo({
      url: `/pages/A-follow/evaluate/evaluate`,
    })
  },

  //查看约茶信息
  toTeaDetail: function () {
    let that = this;
    wx.navigateTo({
      url: `/pages/B-follow/B-myTea/B-teaDetail/B-teaDetail`,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})