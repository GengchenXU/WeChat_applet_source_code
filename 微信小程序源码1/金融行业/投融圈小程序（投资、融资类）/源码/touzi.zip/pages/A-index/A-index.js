//index.js
//获取应用实例
const app = getApp();
import {toTabPage} from "../../utils/common.js"
Page({
  data: {
    nowRole:0,
    currentIndex:0
  },
  onLoad: function () {
    
  
  },
  onshow:function(){

  },
  //toggleView
  toggleView: function (event){
    let that = this;
    let currentIndex = that.data;
    currentIndex = event.target.dataset.index;
    that.setData({
      currentIndex
    })
  },
  //swiper切换
  toggleSwiper:function(event){
    let that = this;
    let nowRole = that.data;
    nowRole = event.detail.current;
    that.setData({
      nowRole
    })
  },
  //跳转到详情页
  toDetail:(event)=>{
    let type = event.currentTarget.dataset.type;
    let url;
    if(type == "people"){
      url = `/pages/A-investmentDetails/A-investmentDetails`
    }else {
      url = `/pages/A-investmentDetails/A-investment-organization/A-investment-organization`
    }
    wx.navigateTo({
      url: url,
    })
  },
  // tab切换
  toTabPage:function(e){
    toTabPage(e)
  }

})
