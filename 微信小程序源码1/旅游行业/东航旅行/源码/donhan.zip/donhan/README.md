# 微信小程序－订机票

### 说明：

实现订机票功能，特色：
- 实现小图标动画功能
- 实现数字加减组件

### 数据接口:

使用本地数据

### 目录结构：

- images — 存放项目图片文件
- pages — 存放项目页面文件
- utils — 存放项目页面文件

### 开发环境：

微信web开发者工具 v0.11.112301

### 项目截图：

https://www.getweapp.com/project?projectId=583ecd66e8ff074c22472f4d

### 感谢：

本项目原始版本由GaoQ1提供：https://github.com/GaoQ1/wxapp
