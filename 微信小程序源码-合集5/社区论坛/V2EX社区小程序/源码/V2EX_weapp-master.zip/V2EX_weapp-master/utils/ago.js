/**
 * ago(ms)
 * @param ms : Number (required)
 */
export default function ago(ms) {
  if (!ms) throw new TypeError('ms is not defined')
  let
    now = Date.now(),
    gap = now - ms * 1000,
    seconds = Math.round(gap / 1000)
  
  if (seconds < 60) {
    return `${seconds} 秒前`
  } else {
    let minutes = Math.round(seconds / 60)
    if (minutes < 60) {
      return `${minutes} 分钟前`
    } else {
      let hours = Math.round(minutes / 60)
      if (hours < 24) {
        return `${hours} 小时前`
      } else {
        let date = Math.round(hours / 24)
        return `${date} 天前`
      }
    }
  }
}