/**
 * format(ms[, timeFormat])
 * @param ms : Number (required)
 * @param timeFormat : String
 * @return formatedTime : String
 */
function format(ms, timeFormat='yyyy-MM-dd hh:mm:ss +08:00') {
  if (!ms) throw new TypeError('ms is not defined')
  let
    time = new Date(ms * 1000),
    year = time.getFullYear(),
    month = time.getMonth() + 1,
    date = time.getDate(),
    hours = time.getHours(),
    minutes = time.getMinutes(),
    seconds = time.getSeconds()

  let
    yearLen = timeFormat.match(/y/g).length,
    yearFormat = ''.slice.call(year, -yearLen),
    formatedTime = ''

  formatedTime = timeFormat
    .replace(/y+/g, yearFormat)
    .replace(/M+/g, month < 10 ? '0' + month : month)
    .replace(/d+/g, date < 10 ? '0' + date : date)
    .replace(/h+/g, hours < 10 ? '0' + hours : hours)
    .replace(/m+/g, minutes < 10 ? '0' + minutes : minutes)
    .replace(/s+/g, seconds < 10 ? '0' + seconds : seconds)

  return formatedTime
}

export default format