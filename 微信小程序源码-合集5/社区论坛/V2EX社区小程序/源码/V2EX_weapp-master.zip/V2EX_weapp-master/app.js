import fetch from '/utils/fetch.js'
import ago from '/utils/ago.js'

App({
  "globalData": {
    userInfo: null,
    data: null,
    content: null
  },
  onLaunch() {
    fetch('https://wx.acsad.cn/members/nijjba').then((res) => {
      this.globalData.userInfo = res.data
    })
  }
})
