## 基于 V2EX社区开放的[API接口](https://www.v2ex.com/p/7v9TEc53)写的微信小程序
> 注：由于V2EX社区开放的API接口限制，本项目只实现数据展示（无法发表评论及主题内容），本项目首页初始加载10条最热主题内容，下拉刷新之后更新多条最近主题内容，导航栏第一个选项展示用户主页信息（目前暂不支持注册登录），第二个选项展示记事本页面，第三个选项展示发布主题内容页面

## 技术栈
微信小程序 + ES6 + flex + nodejs + koa + koa-router

## 关于数据接口
由于小程序开发平台对网络请求有所限制，无法直接调用V2EX开放接口，本项目使用 koa + koa-router 中间件 和 nginx 反向代理为小程序提供API

## 目录解构
```
│   app.js
│   app.json
│   app.wxss        //全局样式表
│
├───components      //公共组件（包括头部、底部、和面包屑导航）
├───pages           
│   ├───about       //关于页面
│   ├───comment     //发布评论页（导航栏第三项）
│   ├───config      
│   ├───content     //内容页（点击主题后进入的页面）
│   ├───gravatar    //用户主页（导航栏第一项）
│   ├───index       //首页（进入小程序的首屏页面）
│   ├───more
│   └───notepad     //记事本页面（导航栏第二项）
├───static
│   └───img         //图片静态文件夹
└───utils           //工具函数（用wx.request封装了fetch函数、日期格式化函数、多久以前函数）
```

## 项目截图
![截图1](./static/display01.jpg)
![截图2](./static/display02.gif)
![截图3](./static/display03.jpg)
![截图4](./static/display04.jpg)
![截图5](./static/display05.gif)
![截图6](./static/display06.gif)
