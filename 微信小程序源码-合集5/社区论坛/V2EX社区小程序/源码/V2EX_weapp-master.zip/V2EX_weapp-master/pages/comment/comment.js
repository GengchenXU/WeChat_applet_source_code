Page({
  data:{
    words: 500,
    isTimeLine: true,
    inputDisabled: false
  },
  toggleBar(e) {
    if (e.target.id === 'timeline') {
      this.setData({ isTimeLine: true })
    } else {
      this.setData({ isTimeLine: false })
    }
  },
  countWords(e) {
    let wordsLen = e.detail.value.length
    this.setData({ words: 500 - wordsLen })
  }
})