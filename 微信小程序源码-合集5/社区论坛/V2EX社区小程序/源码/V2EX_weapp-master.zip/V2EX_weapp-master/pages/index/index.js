import fetch from '../../utils/fetch.js'
import ago from '../../utils/ago.js'

Page({
  onLoad() {
    this.initData()
  },
  initData() {
    let data = getApp().globalData.data

    if (!data) {
      wx.showLoading({
        title: ' '
      })
      fetch('https://wx.acsad.cn').then(res => {
        let data = []

        res.data.forEach(obj => {
          data.push(Object.assign(obj, { ago: ago(obj.last_modified) }))
        })

        this.setData({ data })
        getApp().globalData.data = data
        wx.hideLoading()
      })
    } else {
      this.setData({ data })
    }
  },
  gotoContent(e) {
    let contentData = e.currentTarget.dataset

    getApp().globalData.contentData = contentData

    wx.redirectTo({
      url: `/pages/content/content`,
    })
  },
  onPullDownRefresh() {
    fetch('https://wx.acsad.cn/latest').then(res => {
      let
        data = this.data.data,
        dataSet = new Set(),
        dataLen = data.length

      data.forEach(obj => {
        dataSet.add(obj.id)
      })

      res.data.forEach(obj => {
        if (!dataSet.has(obj.id)) {
          dataSet.add(obj.id)
          data.unshift(Object.assign(obj, { ago: ago(obj.last_modified) }))
        }
      })

      if (dataLen === data.length) {
        wx.showToast({
          title: '没有新的内容',
          image: '/static/img/fail.png'
        })
      }

      this.setData({ data })
      getApp().globalData.data = data
    })
    wx.stopPullDownRefresh()
  }
})