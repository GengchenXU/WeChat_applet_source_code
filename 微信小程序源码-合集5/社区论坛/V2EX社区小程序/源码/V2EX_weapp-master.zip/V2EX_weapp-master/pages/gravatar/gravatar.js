import format from '../../utils/format.js'

Page({
  onLoad() {
    this.initData()
    this.renderCrumbs()
  },
  renderCrumbs() {
    let
      pages = getCurrentPages(),
      routes = {}

    for (let page of pages) {
      let
        path = page.route,
        pageName = page.route.split('/')[1]

      routes[pageName] = path
    }

    this.setData({ routes })
  },
  initData() {
    let
      data = getApp().globalData.userInfo,
      isFound = data.status === 'found',
      id = data.id,
      avatarPath = data.avatar_mini,
      userName = data.username,
      created = format(data.created)

    this.setData({ isFound, id, avatarPath, userName, created })
  }
})