Page({
  onLoad(option) {
    this.render()
  },
  render() {
    let 
      globalData = getApp().globalData,
      contentData = globalData.contentData,
      userData = globalData.userInfo

    this.setData({
      nodes: contentData.content,
      avatar: contentData.avatar,
      title: contentData.title,
      userData
    })
  }
})