export default {
  basePath: 'https://api.myjson.com/bins/pl389',
  fileBasePath: 'https://api.myjson.com/bins/pl389',
  // basePath: 'http://localhost:8001/api/v1',
  // fileBasePath: 'http://localhost:8001/api/v1',
  appId: 'wxf76a1dc18f473516',
	ihakula_request: 'ihakula_northern_hemisphere',
}
