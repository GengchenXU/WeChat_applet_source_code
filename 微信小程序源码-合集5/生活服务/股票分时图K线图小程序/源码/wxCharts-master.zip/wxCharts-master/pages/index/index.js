/**
 * Created by ChenChao on 2016/9/27.
 */

var app = getApp();

Page({
    data: {
    },
    onLoad: function () {
        //
    }
});
